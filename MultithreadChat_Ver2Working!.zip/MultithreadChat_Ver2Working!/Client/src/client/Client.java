/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.Random;
import java.sql.*;
import java.sql.Statement;
import java.util.*;
//import java.sql.Connection;
//import java.sql.DriverManager;
/**
 *
 * @author USER
 */
public class Client extends Application {
    public String sHistoryOfSentMessages="";
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        //Scene scene = new Scene(root);
        Random r = new Random();
        int i = r.nextInt(2);
        // We assume that login happened successdully for user 0 and user 1, and we would need
        // to show the name of the user who passed login by username and paasword
        // 0 - User=Bob username=bob password=12345
        // 1 - User=Nickolay username=nick3 password=67890
        String query = "";
        if (i==0) //0 - User=Bob username=bob password=12345
        {
            query = "SELECT user_name FROM user WHERE user_login='bob' AND user_password='12345'";
            //ps.setString(1, "bob");
            //ps.setString(2, "12345");
        }
        else //1=User=Nickolay username=nick3 password=67890
        {
            query = "SELECT user_name FROM user WHERE user_login='nick3' AND user_password='67890'";
            //ps.setString(1, "nick3");
            //ps.setString(2, "67890");
        }
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/world?useSSL=false","root","DeltaDental!");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            String sUserName="";
            if(rs.next()){
                sUserName=rs.getString("user_name");
            }
            //ResultSet rs = stmt.executeQuery();
            //while (rs.next())
            //{
            //    int foo = rs.getInt(1);
            //}
            stage.setScene(new Scene(root));
            stage.setTitle("ChatWindow for user: "+sUserName);

            stage.show();

            // Now do something with the ResultSet ....
        }
        catch (SQLException ex){
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) { } // ignore

                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) { } // ignore

                stmt = null;
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
